                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:25149
Inmoov Robot Rotation Wrist by Gael_Langevin is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

IMPORTANT: If you want the latest updates visit my site:
http://www.inmoov.fr
This part is a rotational wrist for the hand robot "InMoov", 
For more parts and info, see thingiverse.com/thing:17773

Assembly instructions, see
http://www.inmoov.fr


youtube.com/watch?v=BAs2F4sFVdA

youtube.com/watch?v=tXYF6yY1c9M

Video of rotation wrist:
youtube.com/watch?v=lkmXFKQgZm8

# Instructions

Full instructions and updated files here:
http://www.inmoov.fr

I should have made this part from the beginning, but at the time I never thought I would go that far with this project.  
If you have already assembled the hand with it's rods, well first I have to say: Good job! But now let's take it a little apart again.  
I have put many pictures of the assembly on my blog.  
This thing can replace "robpart1" or "leftrobpart1" depending on which hand you did.  
If you have or plan to make the left hand, print the parts that begin with "leftxxxx".  
"cableholderwrist1", "rotawrist3" and "wristgears3" are for the right and left hand.  
The gears inside are fine little things and require good tunning on your printer. I printed them at 0.4 thickness in ABS. They should be well finished other wise they won't fit or slip.  

Update 24/06/12 modified "wristgears2" to "wristgears3", the others were losing steps after a while. The teeth were too fine for the torque.  
Update 22/02/14 modified CableHolderWristV3 to V4. The V3 version was less easy to keep the cables in place during the closing assembly of the whole wrist.